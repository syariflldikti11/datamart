<div class="container-fluid">
<div class="row">
            <div class="col-12">
              <div class="card">
                <div class="border-bottom title-part-padding">
                  <h4 class="card-title mb-0"> <?= $judul; ?></h4>
                  <br />
             <b>     Note : Dosen homebase adalah dosen dengan status (Dosen Tetap, Dosen PNS DPK, Dosen dengan perjanjian kerja)</b>
                </div>
                <div class="card-body">
                  
                  <div class="table-responsive">
                  
                  <table id="tb_dosen" class="table table-striped table-bordered">
                      <thead>
                        <tr>
                          <th>No</th>
                          <th>Kode PT</th>
                          <th>Nama PT</th>
                          <th>Provinsi PT</th>
                          <th>Registrasi</th>
                          <th>No Reg</th>
                          <th>Nama</th>
                          <th>JK</th>
                          <th>Pendidikan</th>
                          <th>Jabatan Akademik</th>
                          <th>Ikatan Kerja</th>
                          <th>Status Aktif</th>
                         
                        
                        
                        </tr>
                      </thead>
                     
                      
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>