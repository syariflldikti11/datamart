<?php
	
class M_si extends CI_model{
	
		

	
}